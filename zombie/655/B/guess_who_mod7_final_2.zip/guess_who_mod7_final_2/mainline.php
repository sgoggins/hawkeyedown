<!doctype = html>
<html>

<form action="process.php" method="POST" name="form1" target="_blank">
    Beginning Date: <input type="text" name="date1" value="2012-04-08"> (yyyy-mm-dd) &nbsp;
    Ending Date: <input type="text" name="date2" value="2012-04-30"> (yyyy-mm-dd)<br><br>    
    Topic 1: <input type="text" name="topc1" value="economy">  &nbsp;
	Topic 2: <input type="text" name="topc2" value="education">  &nbsp;
	Topic 3: <input type="text" name="topc3" value="healthcare">  &nbsp;
	Topic 4: <input type="text" name="topc4" value="immigration">  &nbsp;
	Topic 5: <input type="text" name="topc5" value="abortion">  <br /><br />
    <input type="submit" value="Generate">
    <p>&nbsp;</ p>
    <hr>
</form>
    
</html>