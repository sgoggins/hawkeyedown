<!DOCTYPE html>
<html>
	<head>
		<title>TweetMap - Versus!</title>
        <link type="text/css" rel="stylesheet" href="css/main.css"/>
	</head>
	<body>



        <div id="wrapper">
            <div id="col1">
                <iframe src="versusData.php" frameborder="0" scrolling="no" width="100%" height="2350px"></iframe>
            </div>
            <div id="col2">
                <iframe src="versusData.php?hashtag=obama" frameborder="0" scrolling="no"  width="100%" height="2350px"></iframe>
            </div>
            <div id="mid">
                <p>VS.</p>
            </div>
            <div id="bottom"></div>
        </div>
    
	</body>
</html>

